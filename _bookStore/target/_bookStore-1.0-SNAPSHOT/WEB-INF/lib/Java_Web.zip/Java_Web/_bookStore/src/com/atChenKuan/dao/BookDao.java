package com.atChenKuan.dao;

import com.atChenKuan.pojo.Book;

import java.util.List;

/**
 * @author 陈宽
 * @create 2021-03-01 22:50
 * @description  在数据库中对图书信息进行增删改查的具体操作
 */
public interface BookDao {

    /**
     * 增加图书信息
     * @param book
     * @return
     */
    public int addBook(com.atChenKuan.pojo.Book book);

    /**
     * 删除图书信息
     * @param id
     * @return
     */
    public int deleteBook(Integer id);

    /**
     * 更新图书信息
     * @param book
     * @return
     */
    public int updateBook(com.atChenKuan.pojo.Book book);

    /**
     * 根据图书ID查询图书
     * @param id
     * @return
     */
    public com.atChenKuan.pojo.Book queryBookById(Integer id);

    /**
     * 返回所有图书信息
     * @return
     */
    public List<Book> queryBooks();

    public Integer queryForPageTotalCount();

    public List<Book> queryForPageItems(int begin, int pageSize);
}
