package com.atChenKuan.web;

import com.atChenKuan.pojo.User;
import com.atChenKuan.service.UserService;
import com.atChenKuan.service.impl.UserServiceImpl;
import com.atChenKuan.utils.webUtils;
import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Map;

/**
 * @author 陈宽
 * @create 2021-02-27 21:46
 * @description  只需要写实现的方法，方法的执行doPost()由父类BaseServlet实现
 */
public class UserServlet extends baseServlet {
    private UserService userService = new UserServiceImpl();

    /**
     * 处理登录
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void login(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获得参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        //2.进行用户名和密码的验证(调用XXXXServlet.xxx()处理业务
        //userService.login()登录
        User loginUser = userService.login(new User(username, password, null));
        //如果等于null,则登录失败
        if(loginUser == null){
            req.setAttribute("msg","用户名或密码错误");
            req.setAttribute("username",username);
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req,resp);
        }else{
            //登录成功，跳转到login_success
            req.setAttribute("username",username);
            req.getRequestDispatcher("/pages/user/login_success.jsp").forward(req,resp);
//            System.out.println("登录成功");
        }
    }

    /**
     * 处理注册
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    protected void regist(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获取请求参数
        String username = req.getParameter("username");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String verification = req.getParameter("verification");

        //通过BeanUtils注入参数
        /*
           BeanUtils.populate(bean,value);     这个方法会搜索请求的jsp页面所有的带有name属性的标签，并获取该标签的value值
           然后通过赋给某个javaBean对象，搜索这个对象里跟name一样的属性，如果有，就调用该javabean里面的set()方法进行赋值
        * */
        User user = webUtils.copyParamToBean(req.getParameterMap(), new User());
//        System.out.println(user.toString());
//        Map<String,String[]> map = req.getParameterMap();
//        for(Map.Entry<String,String[]> entry : map.entrySet()){
//            System.out.println(entry.getKey() + "=" + Arrays.asList(entry.getValue()));
//        }

        //2.检查验证码是否正确
        if ("abcd".equalsIgnoreCase(verification)){
            //验证码正确
            //3.检查用户名是否可用
            if (userService.existsUsername(username)){
                //用户名可以使用
                //4.调用Servlet保存到数据库
                //跳转到注册成功页面  regist_success.jsp
                System.out.println("用户名[ " + user.getUsername() + " ]可以使用" );
                userService.registUser(new User(username,password,email));
                req.getRequestDispatcher("/pages/user/regist_success.jsp").forward(req,resp);
            }else {
                //用户名已经存在,把回显信息保存到request域中
                req.setAttribute("msg","用户名已经存在");
                System.out.println("用户名[ " + username + " ]不可用");
                req.getRequestDispatcher("/pages/user/regist.jsp").forward(req,resp);
            }
        } else {
            //验证码错误，跳转回当前注册页面
            req.setAttribute("msg","验证码错误");
            req.setAttribute("username",username);
            req.setAttribute("email",email);
            System.out.println("验证码[ " + verification + " ]错误");
            req.getRequestDispatcher("/pages/user/regist.jsp").forward(req,resp);
        }
    }

}
