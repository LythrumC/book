package com.atChenKuan.web;

import com.atChenKuan.pojo.User;
import com.atChenKuan.service.UserService;
import com.atChenKuan.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * @author 陈宽
 * @create 2021-02-21 16:05
 * @description
 */
public class loginServlet extends HttpServlet {
    private UserService userService = new UserServiceImpl();
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1.获得参数
        String username = req.getParameter("username");
        String password = req.getParameter("password");

        //2.进行用户名和密码的验证(调用XXXXServlet.xxx()处理业务
        //userService.login()登录
        User loginUser = userService.login(new User(username, password, null));
        //如果等于null,则登录失败
        if(loginUser == null){
            req.setAttribute("msg","用户名或密码错误");
            req.setAttribute("username",username);
            req.getRequestDispatcher("/pages/user/login.jsp").forward(req,resp);
        }else{
            //登录成功，跳转到login_success
            req.getRequestDispatcher("/pages/user/login_success.jsp").forward(req,resp);
            System.out.println("登录成功");
        }
    }
}
